from sklearn.externals import joblib
from sklearn import svm
import numpy as np
import os,cv2
PATH = os.getcwd()
# Define data path
data_path = PATH + '/data'
data_dir_list = os.listdir(data_path)
data_path1 = PATH + '/data1'
data_dir_list1 = os.listdir(data_path1)
img_rows=128
img_cols=128
num_channel=1
num_epoch=10

# Define the number of classes
img_data_list1=[]

#print training_data
  # build a one class svm model
for dataset in data_dir_list1:
	img_list=os.listdir(data_path1+'/'+ dataset)
	print ('Loaded the images of dataset-'+'{}\n'.format(dataset))
	for img in img_list:
                print img
		input_img1=cv2.imread(data_path1 + '/'+ dataset + '/'+ img )
		input_img1=cv2.cvtColor(input_img1, cv2.COLOR_BGR2GRAY)
		input_img_resize1=cv2.resize(input_img1,(128,128))
                input_img_resize2=input_img_resize1.flatten()
		img_data_list1.append(input_img_resize2)

test_data = np.array(img_data_list1)
test_data = test_data.astype('float32')
test_data /= 255
clf = joblib.load('finalized_model.h5') 
y_pred_test = clf.predict(test_data)
print y_pred_test

 
