from sklearn.datasets import fetch_mldata
from sklearn import svm
from sklearn.cross_validation import train_test_split
import numpy as np
from collections import Counter
import cPickle
import gzip
import os,cv2
#def oneclass_svm_baseline():
  #mnist = fetch_mldata('MNIST original', data_home='../ScikitData')
  #Xtr,Xts,Ytr,Yts = train_test_split(mnist.data, mnist.target, test_size=10000, random_state=42)
#f = gzip.open('data.tar.gz','rb')
#input_img=cv2.imread('/home/rac/DRP_Python/classify_documents/codes/Novelty_Detection/data/train')
#input_img=cv2.cvtColor(input_img, cv2.COLOR_BGR2GRAY)
#input_img=cv2.resize(input_img,(128,128))
PATH = os.getcwd()
# Define data path
data_path = PATH + '/data'
data_dir_list = os.listdir(data_path)
data_path1 = PATH + '/data1'
data_dir_list1 = os.listdir(data_path1)
img_rows=128
img_cols=128
num_channel=1
num_epoch=10

# Define the number of classes


img_data_list=[]
img_data_list1=[]
for dataset in data_dir_list:
	img_list=os.listdir(data_path+'/'+ dataset)
	print ('Loaded the images of dataset-'+'{}\n'.format(dataset))
	for img in img_list:
		input_img=cv2.imread(data_path + '/'+ dataset + '/'+ img )
		input_img=cv2.cvtColor(input_img, cv2.COLOR_BGR2GRAY)
		input_img_resize=cv2.resize(input_img,(128,128))
                input_img_resize=input_img_resize.flatten()
		img_data_list.append(input_img_resize)


training_data = np.array(img_data_list)
training_data = training_data.astype('float32')
training_data /= 255

#print training_data
  # build a one class svm model
for dataset in data_dir_list1:
	img_list=os.listdir(data_path1+'/'+ dataset)
	print ('Loaded the images of dataset-'+'{}\n'.format(dataset))
	for img in img_list:
                print img
		input_img1=cv2.imread(data_path1 + '/'+ dataset + '/'+ img )
		input_img1=cv2.cvtColor(input_img1, cv2.COLOR_BGR2GRAY)
		input_img_resize1=cv2.resize(input_img1,(128,128))
                input_img_resize2=input_img_resize1.flatten()
		img_data_list1.append(input_img_resize2)

test_data = np.array(img_data_list1)
test_data = test_data.astype('float32')
test_data /= 255

clf = svm.OneClassSVM(nu=0.1, kernel="rbf", gamma=0.02)
clf.fit(training_data)    
y_pred_test = clf.predict(test_data)
print y_pred_test
#y_pred_outliers = clf.predict(X_outliers)
 
